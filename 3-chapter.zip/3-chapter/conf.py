import numpy as np

IP = 'localhost'
PORT = 3306
USER_NAME = 'root'
PASSWD = '12345'
pretrain_DATABASE = 'dd'
CNN_TABLENAME = 'new_cnn_3value'  #(used to pretrain SL policy network)

DQN_TABLENAME = 'list_dd_and_color'  #(used to train DQN based on CNN)


GAME = 'follower'
ACTIONS =3
BATCH=32
MAX_BATCH = 3200

train_start_id =1
train_end_id=500000

validation_start_id =500001
validation_end_id=600000

test_start_id =600001
test_end_id=741649



