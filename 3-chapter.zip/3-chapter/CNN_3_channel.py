#!/usr/bin/env python
from __future__ import print_function
import tensorflow as tf
import random
import numpy as np
import pymysql
import json
import os
import conf
import pickle
from tensorflow.core.protobuf import saver_pb2
np.set_printoptions(threshold=np.nan)

IP = conf.IP
PORT = conf.PORT
USER_NAME = conf.USER_NAME
PASSWD = conf.PASSWD
pretrain_DATABASE = conf.pretrain_DATABASE
TABLENAME = conf.CNN_TABLENAME

GAME = conf.GAME  # the name of the game being played for log files
ACTIONS = conf.ACTIONS  # number of valid actions
BATCH = conf.BATCH  # size of minibatch
MAX_BATCH = conf.MAX_BATCH
#MAX_BATCH = 10


def train_next_batch(cursor, BATCH):
    '''
    training data is from list_cnn_3value table ,and the id_range is :1~ 2528
    '''
    '''
    max_id_query = """select max(id) from new_cnn_3value"""
    cursor.execute(max_id_query)
    max_id = cursor.fetchall()  # a tuple ((max_id))
    max_id = max_id[0][0]
    '''
    start_id = conf.train_start_id
    end_id=conf.train_end_id
    random_batch_id = random.sample(
        range(start_id, end_id + 1), BATCH)  # [12,34,6,7,68,0]

    random_batch_tuple = tuple(random_batch_id)

    batch_query = """select s_t, a_t from new_cnn_3value where id in """
    cursor.execute(batch_query + str(random_batch_tuple))
    results = cursor.fetchall()
    s_j_batch = [np.array(json.loads(result[0])) for result in results]
    a_batch = [np.array(json.loads(result[1])) for result in results]
    return s_j_batch, a_batch


def test_next_batch(cursor, BATCH):
    '''
    test data is from cnn_3_value_testandvalidation table
    '''
    start_id = conf.test_start_id
    end_id = conf.test_end_id
    random_batch_id = random.sample(
        range(start_id, end_id + 1), BATCH)  # [12,34,6,7,68,0]

    random_batch_tuple = tuple(random_batch_id)

    batch_query = """select s_t, a_t from new_cnn_3value where id in """
    cursor.execute(batch_query + str(random_batch_tuple))
    results = cursor.fetchall()
    s_j_batch = [np.array(json.loads(result[0])) for result in results]
    a_batch = [np.array(json.loads(result[1])) for result in results]
    return s_j_batch, a_batch


def validation_next_batch(cursor, BATCH):
    '''
     validation data is from new_cnn_3value table
     '''
    start_id = conf.validation_start_id
    end_id = conf.validation_end_id
    random_batch_id = random.sample(
        range(start_id, end_id + 1), BATCH)  # [12,34,6,7,68,0]

    random_batch_tuple = tuple(random_batch_id)

    batch_query = """select s_t, a_t from new_cnn_3value where id in """
    cursor.execute(batch_query + str(random_batch_tuple))
    results = cursor.fetchall()
    s_j_batch = [np.array(json.loads(result[0])) for result in results]
    a_batch = [np.array(json.loads(result[1])) for result in results]
    return s_j_batch, a_batch


def train_process(cursor, BATCH, i, keep_prob, a, s, sess, variables_to_run, train_writer):
    s_j_batch, a_batch = train_next_batch(cursor, BATCH)
    _, c, train_accuracy, summ_train = sess.run(variables_to_run, feed_dict={
        a: a_batch,
        s: s_j_batch,
        keep_prob: 0.5})
    print("during training, STEP is {},cross_entropy is {}, train_accuracy is{}".format(
        i, c, train_accuracy))
    os.system('echo %f >> ./record_curve/cross_entropy.txt' % c)
    train_writer.add_summary(summ_train, i)


def validation_process(cursor, BATCH, i, keep_prob, a, s, sess, variables_to_run, validation_writer):
    validation_s_j_batch, validation_a_batch = validation_next_batch(
        cursor, BATCH)
    validation_error, validation_accuracy, summ_validation = sess.run(variables_to_run, feed_dict={
        a: validation_a_batch,
        s: validation_s_j_batch,
        keep_prob: 1.0})
    print("during validation, validation accuracy is {}".format(validation_accuracy))
    os.system('echo %f >> ./record_curve/validation_accuracy.txt' % validation_accuracy)
    validation_writer.add_summary(summ_validation, i)


def test_process(cursor, BATCH, i, keep_prob, a, s, sess, variables_to_run, test_writer):
    test_s_j_batch, test_a_batch = test_next_batch(cursor, BATCH)
    test_error, test_accuracy, summ_test = sess.run(variables_to_run, feed_dict={
        a: test_a_batch,
        s: test_s_j_batch,
        keep_prob: 1.0})
    print("during testing, test accuracy is {}".format(test_accuracy))
    os.system('echo %f >> ./record_curve/test_accuracy.txt' % test_accuracy)
    test_writer.add_summary(summ_test, i)


def weight_variable(shape, name):
    initial = tf.truncated_normal(shape, stddev=0.01)
    return tf.Variable(initial, name)


def bias_variable(shape, name):
    initial = tf.constant(0.01, shape=shape)
    return tf.Variable(initial, name)


def conv2d(x, W, stride):
    return tf.nn.conv2d(x, W, strides=[1, stride, stride, 1], padding="SAME")


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")


def variable_summaries(var, name):
    """Attach a lot of summaries to a Tensor (for TensorBoard visualization)."""
    with tf.name_scope('summaries'):
        mean = tf.reduce_mean(var)
        tf.scalar_summary('mean/' + name, mean)
        with tf.name_scope('stddev'):
            stddev = tf.sqrt(tf.reduce_mean(tf.square(var - mean)))
        tf.scalar_summary('stddev/' + name, stddev)
        tf.scalar_summary('max/' + name, tf.reduce_max(var))
        tf.scalar_summary('min/' + name, tf.reduce_min(var))
        tf.histogram_summary('histogram/' + name, var)


def create_pretrain_Network():
    # input layer
    with tf.name_scope('input_states'):
        s = tf.placeholder("float", [None, 60, 80, 12])

    # network weights
    with tf.name_scope('weights_and_bias'):
        W_conv1 = weight_variable([8, 8, 12, 32], "W_conv1")
        b_conv1 = bias_variable([32], "b_conv1")

        W_conv2 = weight_variable([4, 4, 32, 64], "W_conv2")
        b_conv2 = bias_variable([64], "b_conv2")

        W_conv3 = weight_variable([2, 2, 64, 64], "W_conv3")
        b_conv3 = bias_variable([64], "b_conv3")

        W_fc1 = weight_variable([384, 384], "W_fc1")
        b_fc1 = bias_variable([384], "b_fc1")

        W_fc2 = weight_variable([384, ACTIONS], "W_fc2")
        b_fc2 = bias_variable([ACTIONS], "b_fc2")


    # hidden layers
    with tf.name_scope('conv_layer_1'):
        h_conv1 = tf.nn.relu(conv2d(s, W_conv1, 2) + b_conv1)
        h_pool1 = max_pool_2x2(h_conv1)

    with tf.name_scope('conv_layer_2'):
        h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2, 2) + b_conv2)
        h_pool2 = max_pool_2x2(h_conv2)

    with tf.name_scope('conv_layer_3'):
        h_conv3 = tf.nn.relu(conv2d(h_pool2, W_conv3, 1) + b_conv3)
        h_pool3 = max_pool_2x2(h_conv3)

    with tf.name_scope('feature_repre_layer'):
        h_conv3_flat = tf.reshape(h_pool3, [-1, 384])

    with tf.name_scope('fcn_layer_1'):
        h_fc1 = tf.nn.relu(tf.matmul(h_conv3_flat, W_fc1) + b_fc1)

    with tf.name_scope('dropout_layer'):
        keep_prob = tf.placeholder(tf.float32)
        h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

        # readout layer
    with tf.name_scope('action_value_layer'):
        readout = tf.matmul(h_fc1_drop, W_fc2) + b_fc2
    # readout = tf.nn.softmax(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)

    variable_summaries(W_conv1, 'W_conv1')
    variable_summaries(b_conv1, 'b_conv1')
    variable_summaries(W_conv2, 'W_conv2')
    variable_summaries(b_conv2, 'b_conv2')
    variable_summaries(W_conv3, 'W_conv3')
    variable_summaries(b_conv3, 'b_conv3')
    variable_summaries(W_fc1, 'W_fc1')
    variable_summaries(b_fc1, 'b_fc1')
    variable_summaries(W_fc2, 'W_fc2')
    variable_summaries(b_fc2, 'b_fc2')


    return s, readout, keep_prob, W_conv1, b_conv1, W_conv2, b_conv2, W_conv3, b_conv3, W_fc1, b_fc1, W_fc2, b_fc2


def train_and_test_cnn_Network(s, readout, keep_prob, W_conv1, b_conv1, W_conv2, b_conv2, W_conv3, b_conv3, W_fc1, b_fc1, W_fc2, b_fc2, sess, cursor):
        # define the cost function
    with tf.name_scope('input_action_label'):
        a = tf.placeholder("float", [None, ACTIONS])

    with tf.name_scope('cross_entropy_layer'):
        cross_entropy = tf.reduce_mean(
            tf.nn.softmax_cross_entropy_with_logits(labels=a, logits=readout))
        tf.scalar_summary('cross_entropy', cross_entropy)

    with tf.name_scope('train'):
        train_step = tf.train.AdamOptimizer(
            1e-6).minimize(cross_entropy)

    with tf.name_scope('accuracy'):
        with tf.name_scope('correct_prediction'):
            correct_prediction = tf.equal(
                tf.argmax(readout, 1), tf.argmax(a, 1))
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
        tf.scalar_summary('accuracy', accuracy)

    saver = tf.train.Saver(write_version=saver_pb2.SaverDef.V1) 
    merged = tf.merge_all_summaries()
    train_writer = tf.train.SummaryWriter(
        'summary/train', sess.graph)
    test_writer = tf.train.SummaryWriter(
        'summary/test', sess.graph)
    validation_writer = tf.train.SummaryWriter(
        'summary/validation', sess.graph)
    # saver = tf.train.Saver(write_version=saver_pb2.SaverDef.V1)
    sess.run(tf.initialize_all_variables())
    checkpoint = tf.train.get_checkpoint_state("pretrained_saved_networks")
    if checkpoint and checkpoint.model_checkpoint_path:
        saver.restore(sess, checkpoint.model_checkpoint_path)
        print("Successfully loaded: pretrained_saved_networks/follower_dqn")
    else:
        print("Could not find old network weights")

    # *****************train_process_start*******************/
    for i in range(MAX_BATCH):
        # train process
        variables_to_run_train = [train_step, cross_entropy, accuracy, merged]
        train_process(cursor, BATCH, i, keep_prob, a, s, sess,
                      variables_to_run_train, train_writer)
        variables_to_run_validation = [cross_entropy, accuracy, merged]
        validation_process(cursor, BATCH, i, keep_prob, a, s,
                           sess, variables_to_run_validation, validation_writer)
        variables_to_run_test = [cross_entropy, accuracy, merged]
        test_process(cursor, BATCH, i, keep_prob,
                     a, s, sess, variables_to_run_test, test_writer)
    
    # *********************train_process_end**********************/
    # *****************validation_process_start*******************/
    for i in range(10):
        validation_s_j_batch, validation_a_batch = validation_next_batch(
            cursor, BATCH)
        validation_accuracy, summ_validation = sess.run([accuracy, merged], feed_dict={
            a: validation_a_batch,
            s: validation_s_j_batch,
            keep_prob: 1.0})
        print("during validation, validation accuracy is {}".format(
            validation_accuracy))
        validation_writer.add_summary(summ_validation, i)

    # *****************validation_process_end*******************/
    # *****************test_process_start*******************/
    for i in range(10):
        test_s_j_batch, test_a_batch = test_next_batch(cursor, BATCH)
        test_accuracy, summ_test = sess.run([accuracy, merged], feed_dict={
            a: test_a_batch,
            s: test_s_j_batch,
            keep_prob: 1.0})
        print("during testing, test accuracy is {}".format(test_accuracy))
        test_writer.add_summary(summ_test, i)
    
    W_conv1, b_conv1, W_conv2, b_conv2, W_conv3, b_conv3, W_fc1, b_fc1, W_fc2, b_fc2 = sess.run(
        [W_conv1, b_conv1, W_conv2, b_conv2, W_conv3, b_conv3, W_fc1, b_fc1, W_fc2, b_fc2])
    with open("weights_of_3channel_CNN.txt", "wb") as fp:
        pickle.dump(W_conv1, fp)
        pickle.dump(b_conv1, fp)
        pickle.dump(W_conv2, fp)
        pickle.dump(b_conv2, fp)
        pickle.dump(W_conv3, fp)
        pickle.dump(b_conv3, fp)
        pickle.dump(W_fc1, fp)
        pickle.dump(b_fc1, fp)
        pickle.dump(W_fc2, fp)
        pickle.dump(b_fc2, fp)

    a = saver.save(sess, "./test_saved_networks/follower_dqn")
    print('model has been saved successfully.')


def playGame():
    sess = tf.InteractiveSession()
    s, readout, keep_prob, W_conv1, b_conv1, W_conv2, b_conv2, W_conv3, b_conv3, W_fc1, b_fc1, W_fc2, b_fc2 = create_pretrain_Network()
    train_and_test_cnn_Network(s, readout, keep_prob, W_conv1, b_conv1, W_conv2,
                               b_conv2, W_conv3, b_conv3, W_fc1, b_fc1, W_fc2, b_fc2, sess, cursor)


if __name__ == "__main__":
    '''
    if tf.gfile.Exists('summary'):
        tf.gfile.DeleteRecursively('summary')
    tf.gfile.MakeDirs('summary')
    '''
    #db = pymysql.connect(host='localhost', port=3306,
    #                     user='root', passwd='3.1415926', db='dd')
    db = pymysql.connect(host=IP, port=PORT, user=USER_NAME, passwd=PASSWD, db=pretrain_DATABASE)
    print("has connected successfully")
    cursor = db.cursor()
    playGame()

