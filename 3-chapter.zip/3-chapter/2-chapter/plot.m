after_path = '/home/plz/workspace/images_prepare/matlab_frames_with_new_background/';
    low=0.2;
    up=0.6;
    
    %up=0.2
    %low=0.1
    %n=24;m=52;
    %n=24;m=73;
    n=24;m=170;

        %for m=0:3451
            %former_index=n-17;   %(212,228)
            original_path_str=strcat(after_path,'background','_',num2str(n),'/',num2str(m),'_',num2str(n),'.jpg');
            current_image = imread(original_path_str);
            [rows,cols,depth]=size(current_image);
            current_frame_hsv=rgb2hsv(current_image);
            current_channel_v=current_frame_hsv(:,:,3);
            random_v_change=low+(up-low).*rand(size(current_channel_v));
            new_channel_v=current_channel_v+random_v_change;
            new_img(:,:,1)=double(current_frame_hsv(:,:,1));
            new_img(:,:,2)=double(current_frame_hsv(:,:,2));
            new_img(:,:,3)=new_channel_v;
            new_img_bgr=hsv2rgb(new_img);
            %change=lower+(upper-lower)*rand(0,1);
            %after_luminance_change=arrayfun(@(x) x.+change, current_channel_v)
            backg_dir_str=strcat(after_path,'background','_',num2str(n));
            %backg_dir_str=strcat('/home/plz/test/','background','_',num2str(n));
            mkdir(backg_dir_str);
            save_dir='/home/plz/workspace/images_prepare/frames_for_plotting/';

            save_path=strcat(save_dir, num2str(m) , '_' , num2str(n) ,'increase','.jpg');
            imwrite(new_img_bgr,save_path,'jpg');
        %end
    %end