import numpy as np
#mysql parameters
IP = 'localhost'
PORT = 3306
USER_NAME = 'root'
PASSWD = '3.1415926'
pretrain_DATABASE = 'dd'
TABLENAME = '0816_new_cnn_3value'
#number of frames and backgrounds
#(index range:0~14)
frames_num=15  
#sequences of (s_t,a_t)
sequences_num=12
backgrounds_num=9
#change illuminance of original images by 20%~60%
low=0.2
up=0.6
#color range of the person
lower_shang = np.array([20, 100, 90])
upper_shang = np.array([30, 255, 255])
