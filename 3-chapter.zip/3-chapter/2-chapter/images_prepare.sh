chmod +x ./*.py
./sort_frames_and_backgrounds.py

matlab -nosplash -nodesktop -nojvm -r "run ./change_background_of_all_frames;run ./change_luminance_of_all_images;quit;"

./test_person_portion_using_upanddown.py

./save_all_frames_and_a_t_tomysql.py
