# --coding:utf-8 --

import seaborn as sns
import matplotlib.pyplot as plt

sns.set_palette('deep',desat=0.6)
sns.set_context(rc={'figure.figsize': (2, 4.2) } )
sns.set(color_codes=True)
sns.set_style('darkgrid')

def plot(filename):
    x = []
    with open(filename, 'r') as f:
        lines =f.readlines()
        for line in lines:
            x.append(float(line.strip()))
    return x

x = plot('./cross_entropy.txt')
sns.tsplot(x[:2500],linewidth=0.5,color="b")
plt.title("cross entropy",fontsize=13)
plt.show()

x = plot('./validation_accuracy.txt')
sns.tsplot(x[:2500],linewidth=0.5,color="y")
plt.title("validation accuracy",fontsize=13)
plt.show()

x = plot('./test_accuracy.txt')
sns.tsplot(x[:2500],linewidth=0.5,color="r")
plt.title("test accuracy",fontsize=13)
plt.show()

