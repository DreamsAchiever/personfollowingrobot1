chmod +x ./*.py
./CNN_3_channel.py

./using_pretrained_CNN.py

