使用方法：
bash pretrain.sh
运行后会在record_curve文件夹下生成三个txt文档，保存训练的数据，
然后使用record_curve下的plot.py脚本画出训练曲线。
