from __future__ import print_function
import tensorflow as tf
import random
import numpy as np
import pickle
import os
from tensorflow.core.protobuf import saver_pb2
import matplotlib


GAME = 'follower'  # the name of the game being played for log files
ACTIONS = 3  # number of valid actions
GAMMA = 0.9  # decay rate of past observations
OBSERVE = 10000  # timesteps to observe before training
EXPLORE = 2000000.  # frames over which to anneal epsilon
REPLAY_MEMORY = 50000  # number of previous transitions to remember
BATCH = 32  # size of minibatch
FRAME_PER_ACTION = 1
MAX_BATCH = 4000


def weight_variable(shape, name):
    initial = tf.truncated_normal(shape, stddev=0.01)
    return tf.Variable(initial, name)


def bias_variable(shape, name):
    initial = tf.constant(0.01, shape=shape)
    return tf.Variable(initial, name)


def conv2d(x, W, stride):
    return tf.nn.conv2d(x, W, strides=[1, stride, stride, 1], padding="SAME")


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")


def variable_summaries(var, name):
    """Attach a lot of summaries to a Tensor (for TensorBoard visualization)."""
    with tf.name_scope('summaries'):
        mean = tf.reduce_mean(var)
        tf.scalar_summary('mean/' + name, mean)
        with tf.name_scope('stddev'):
            stddev = tf.sqrt(tf.reduce_mean(tf.square(var - mean)))
        tf.scalar_summary('stddev/' + name, stddev)
        tf.scalar_summary('max/' + name, tf.reduce_max(var))
        tf.scalar_summary('min/' + name, tf.reduce_min(var))
        tf.histogram_summary('histogram/' + name, var)


class PolicyEstimator():
    """objective function is: log pi(a|s) * (Q(s,a)-V(s))"""

    def __init__(self, learning_rate=1e-6, scope="policy_estimator"):
        with tf.variable_scope(scope):
            self.s = tf.placeholder("float", [None, 60, 80, 12])
            self.action = tf.placeholder("float", [None, ACTIONS])
            self.target = tf.placeholder(dtype=tf.float32, name="target")

            # network weights
            with open("weights_of_3channel_CNN.txt", "rb") as fp:
                W_conv1_cnn = pickle.load(fp)
                b_conv1_cnn = pickle.load(fp)
                W_conv2_cnn = pickle.load(fp)
                b_conv2_cnn = pickle.load(fp)
                W_conv3_cnn = pickle.load(fp)
                b_conv3_cnn = pickle.load(fp)
                W_fc1_cnn = pickle.load(fp)
                b_fc1_cnn = pickle.load(fp)
                W_fc2_cnn = pickle.load(fp)
                b_fc2_cnn = pickle.load(fp)
            # initialize weight variable with saved weights
            W_conv1 = tf.Variable(
                W_conv1_cnn, dtype=tf.float32)  # [8, 8, 12, 32]
            b_conv1 = tf.Variable(b_conv1_cnn, dtype=tf.float32)  # [32]

            W_conv2 = tf.Variable(
                W_conv2_cnn, dtype=tf.float32)  # [4, 4, 32, 64]
            b_conv2 = tf.Variable(b_conv2_cnn, dtype=tf.float32)  # [64]

            W_conv3 = tf.Variable(
                W_conv3_cnn, dtype=tf.float32)  # [2, 2, 64, 64]
            b_conv3 = tf.Variable(b_conv3_cnn, dtype=tf.float32)  # [64]

            W_fc1 = tf.Variable(W_fc1_cnn, dtype=tf.float32)  # [384, 384]
            b_fc1 = tf.Variable(b_fc1_cnn, dtype=tf.float32)  # [384]

            W_fc2 = tf.Variable(W_fc2_cnn, dtype=tf.float32)  # [384, ACTIONS]
            b_fc2 = tf.Variable(b_fc2_cnn, dtype=tf.float32)  # [ACTIONS]

            variable_summaries(W_conv1, 'W_conv1')
            variable_summaries(b_conv1, 'b_conv1')
            variable_summaries(W_conv2, 'W_conv2')
            variable_summaries(b_conv2, 'b_conv2')
            variable_summaries(W_conv3, 'W_conv3')
            variable_summaries(b_conv3, 'b_conv3')
            variable_summaries(W_fc1, 'W_fc1')
            variable_summaries(b_fc1, 'b_fc1')
            variable_summaries(W_fc2, 'W_fc2')
            variable_summaries(b_fc2, 'b_fc2')

            # hidden layers
            h_conv1 = tf.nn.relu(conv2d(self.s, W_conv1, 2) + b_conv1)
            h_pool1 = max_pool_2x2(h_conv1)
            h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2, 2) + b_conv2)
            h_pool2 = max_pool_2x2(h_conv2)
            h_conv3 = tf.nn.relu(conv2d(h_pool2, W_conv3, 1) + b_conv3)
            h_pool3 = max_pool_2x2(h_conv3)
            h_conv3_flat = tf.reshape(h_pool3, [-1, 384])
            h_fc1 = tf.nn.relu(tf.matmul(h_conv3_flat, W_fc1) + b_fc1)
            keep_prob = tf.constant(0.5, dtype=tf.float32)
            h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

            # readout layer
            self.readout = tf.matmul(h_fc1_drop, W_fc2) + b_fc2

            self.action_probs = tf.nn.softmax(self.readout)   #(32,3)
            # sum over all rows
            self.picked_action_prob = tf.reduce_sum(tf.mul(self.action_probs, self.action),reduction_indices=1)  #(32,)

            
            self.picked_action_prob=tf.cast(self.picked_action_prob, tf.float32)  #(32,)
            self.target=tf.cast(self.target, tf.float32)  #(32,)
            print("action_probs shape is:{},picked_action_prob shape is:{},target shape is:{}".format(self.action_probs.get_shape(),self.picked_action_prob.get_shape(),self.target.get_shape()))
            
            #loss and train_op
            self.loss = -tf.reduce_sum(tf.mul(tf.log(self.picked_action_prob), self.target))  # a value
            self.optimizer = tf.train.AdamOptimizer(
                learning_rate=learning_rate)
            self.train_op = self.optimizer.minimize(
                self.loss, global_step=tf.contrib.framework.get_global_step())

    def predict(self, state, sess=None):
        sess = sess or tf.get_default_session()
        return sess.run(self.action_probs, {self.s: state})

    def update(self, state, target, action, sess=None):
        sess = sess or tf.get_default_session()
        feed_dict = {self.s: state, self.target: target,
                     self.action: action}
        _, loss = sess.run([self.train_op, self.loss], feed_dict)
        return loss


class ValueEstimator():
    """target = Q(s,a) - V(s);where V(s) is the expectation of Q(s,a) over all actions"""

    def __init__(self, learning_rate=1e-6, scope="value_estimator"):
        with tf.variable_scope(scope):
            self.s = tf.placeholder("float", [None, 60, 80, 12])
            self.action = tf.placeholder("float", [None, ACTIONS])
            self.target = tf.placeholder(dtype=tf.float32, name="target")

            # network weights
            with open("weights_of_3channel_CNN.txt", "rb") as fp:
                W_conv1_cnn = pickle.load(fp)
                b_conv1_cnn = pickle.load(fp)
                W_conv2_cnn = pickle.load(fp)
                b_conv2_cnn = pickle.load(fp)
                W_conv3_cnn = pickle.load(fp)
                b_conv3_cnn = pickle.load(fp)
                W_fc1_cnn = pickle.load(fp)
                b_fc1_cnn = pickle.load(fp)
                W_fc2_cnn = pickle.load(fp)
                b_fc2_cnn = pickle.load(fp)
            # initialize weight variable with saved weights
            W_conv1 = tf.Variable(
                W_conv1_cnn, dtype=tf.float32)  # [8, 8, 12, 32]
            b_conv1 = tf.Variable(b_conv1_cnn, dtype=tf.float32)  # [32]

            W_conv2 = tf.Variable(
                W_conv2_cnn, dtype=tf.float32)  # [4, 4, 32, 64]
            b_conv2 = tf.Variable(b_conv2_cnn, dtype=tf.float32)  # [64]

            W_conv3 = tf.Variable(
                W_conv3_cnn, dtype=tf.float32)  # [2, 2, 64, 64]
            b_conv3 = tf.Variable(b_conv3_cnn, dtype=tf.float32)  # [64]

            W_fc1 = tf.Variable(W_fc1_cnn, dtype=tf.float32)  # [384, 384]
            b_fc1 = tf.Variable(b_fc1_cnn, dtype=tf.float32)  # [384]

            W_fc2 = tf.Variable(W_fc2_cnn, dtype=tf.float32)  # [384, ACTIONS]
            b_fc2 = tf.Variable(b_fc2_cnn, dtype=tf.float32)  # [ACTIONS]

            variable_summaries(W_conv1, 'W_conv1')
            variable_summaries(b_conv1, 'b_conv1')
            variable_summaries(W_conv2, 'W_conv2')
            variable_summaries(b_conv2, 'b_conv2')
            variable_summaries(W_conv3, 'W_conv3')
            variable_summaries(b_conv3, 'b_conv3')
            variable_summaries(W_fc1, 'W_fc1')
            variable_summaries(b_fc1, 'b_fc1')
            variable_summaries(W_fc2, 'W_fc2')
            variable_summaries(b_fc2, 'b_fc2')

            # hidden layers
            h_conv1 = tf.nn.relu(conv2d(self.s, W_conv1, 2) + b_conv1)
            h_pool1 = max_pool_2x2(h_conv1)
            h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2, 2) + b_conv2)
            h_pool2 = max_pool_2x2(h_conv2)
            h_conv3 = tf.nn.relu(conv2d(h_pool2, W_conv3, 1) + b_conv3)
            h_pool3 = max_pool_2x2(h_conv3)
            h_conv3_flat = tf.reshape(h_pool3, [-1, 384])
            h_fc1 = tf.nn.relu(tf.matmul(h_conv3_flat, W_fc1) + b_fc1)
            # keep_prob = tf.placeholder(tf.float32)
            keep_prob = tf.constant(0.5, dtype=tf.float32)
            h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

            # readout layer
            self.readout = tf.matmul(h_fc1_drop, W_fc2) + b_fc2

            # including values of each state-action pair
            self.value_estimate = self.readout  #(32,3)

            # Q(s,a)
            self.state_action_value = tf.reduce_sum(
                tf.mul(self.readout, self.action), reduction_indices=1)  #(32,)

            #loss and train_op
            self.loss = tf.reduce_mean(
                tf.square(self.state_action_value - self.target))
            self.optimizer = tf.train.AdamOptimizer(
                learning_rate=learning_rate)
            self.train_op = self.optimizer.minimize(
                self.loss, global_step=tf.contrib.framework.get_global_step())

    def predict(self, state, sess=None):
        sess = sess or tf.get_default_session()
        return sess.run(self.value_estimate, {self.s: state})

    def update(self, state, target, action, sess=None):
        sess = sess or tf.get_default_session()
        feed_dict = {self.s: state, self.target: target,
                     self.action: action}
        _, loss = sess.run([self.train_op, self.loss], feed_dict)
        return loss


def Actor_Critic(estimator_policy, estimator_value, sess=None):
    sess = sess or tf.get_default_session()
    with open("average_list_D.txt", "rb") as fp:
        list_D = pickle.load(fp, encoding='latin1')
    if len(list_D) > REPLAY_MEMORY:
        # len(list_D)-REPLAY_MEMORY items need to be deleted
        del_num = len(list_D) - REPLAY_MEMORY
        del_index = random.sample(range(len(list_D)), del_num)
        for j in sorted(del_index, reverse=True):
            del list_D[j]

    saver = tf.train.Saver(write_version=saver_pb2.SaverDef.V1)
    sess.run(tf.initialize_all_variables())
    checkpoint = tf.train.get_checkpoint_state("saved_networks")
    if checkpoint and checkpoint.model_checkpoint_path:
        saver.restore(sess, checkpoint.model_checkpoint_path)
        print("Successfully loaded:", "saved_networks/follower_dqn")
    else:
        print("Could not find old network weights")
    # only train if done observing
    # *****************train_process_start*******************/
    for i in range(MAX_BATCH):
        print("train_epoch :", i)
        # sample a minibatch to train on
        minibatch = random.sample(list_D, BATCH)

        # get the batch variables
        s_j_batch = [d[0] for d in minibatch]
        print("s_j_batch length is:", len(s_j_batch))
        a_batch = [d[1] for d in minibatch]
        r_batch = [d[2] for d in minibatch]
        s_j1_batch = [d[3] for d in minibatch]
        print("s_j1_batch length is:", len(s_j_batch))
        print("s_j_batch[0] shape is:", s_j_batch[0].shape)

        # **************train the critic****************/
        y_batch = []
        readout_j1_batch = estimator_value.predict(s_j1_batch)
        sum_max_Q = 0
        for j in range(0, len(minibatch)):
            terminal = minibatch[j][4]
            # if terminal, only equals reward
            if terminal is True:
                print("terminal is True")
                y_batch.append(r_batch[j])
            else:
                # np.max(readout_j1_batch[i]):the largest Q-value among all
                # actions for the current states
                y_batch.append(r_batch[j] + GAMMA *
                               np.max(readout_j1_batch[j]))
            sum_max_Q += np.max(readout_j1_batch[j])
        average_max_Q = sum_max_Q / float(BATCH)

       # perform gradient step for critic
        c = estimator_value.update(s_j_batch, y_batch, a_batch)

        # **************train the actor****************/
        action_probs = estimator_policy.predict(s_j_batch)  #(32,3)
        readout_j_batch = estimator_value.predict(s_j_batch)
        print("readout_j_batch shape is:{}".format(readout_j_batch.shape))
        a_batch_array = np.array(a_batch).reshape(32,3)
        Q_s_a = tf.reduce_sum(
            tf.mul(a_batch_array, readout_j_batch), reduction_indices=1)
        Q_s_a=tf.cast(Q_s_a, tf.float32)
        print("type of Q_s_a is:{}".format(Q_s_a.dtype))
        V_s = tf.reduce_sum(
            tf.mul(action_probs, readout_j_batch), reduction_indices=1)
        print("type of V_s is:{}".format(V_s.dtype))
        advantage = Q_s_a - V_s  #(32,)
        # update the actor
        estimator_policy.update(s_j_batch, advantage.eval(), a_batch)

        print("STEP is {},cost is {},average_max_Q is:{}".format(i, c, average_max_Q))
        os.system('echo -n %f, >> average_max_Q.txt' % average_max_Q)
        # *********************train_process_end**********************/

    a = saver.save(sess, 'saved_networks/follower_dqn')
    if a == 'saved_networks/follower_dqn':
        print("model has been saved.")


if __name__ == "__main__":
    tf.reset_default_graph()

    global_step = tf.Variable(0, name="global_step", trainable=False)
    policy_estimator = PolicyEstimator()
    value_estimator = ValueEstimator()

    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        Actor_Critic(policy_estimator, value_estimator)
