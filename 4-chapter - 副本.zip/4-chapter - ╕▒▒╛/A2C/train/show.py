import matplotlib
import numpy as np
from matplotlib import pyplot as plt


if os.path.isfile("episode_rewards.txt"):
        print("episode_rewards has existed")
        with open("episode_rewards.txt", "rb") as fp:
            episode_rewards = pickle.load(fp)

fig1 = plt.figure(figsize=(10,5))
plt.plot(episode_rewards)
plt.xlabel("Episode")
plt.ylabel("Episode_rewards")
plt.title("Episode Reward over Time")
plt.close(fig1)
