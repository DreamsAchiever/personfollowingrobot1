import seaborn as sns
import sys
import pandas
import numpy as np
from numpy.random import randn
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy import stats
from sys import argv

sns.set_palette('deep', desat=.6)
sns.set_context(rc={'figure.figsize': (2, 4.2) } )
sns.set(color_codes=True)
sns.set_style('darkgrid')

with open(argv[1],'r') as f:
    line = f.readline()
    data = line.split(",")
    data = [float(item) for item in data[:-1]]

sns.tsplot(data,linewidth=0.5,color="g")

plt.title("a2c",fontsize=13)
plt.show()
